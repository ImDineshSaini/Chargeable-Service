import { useCatalog } from "@/context/CatalogContext";
import PageHeader from "@/components/PageHeader";
import FeatureBadge from "@/components/FeatureBadge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, Layers, Users } from "lucide-react";

const StatCard: React.FC<{ icon: React.ElementType; label: string; value: number; color: string }> = ({
  icon: Icon, label, value, color,
}) => (
  <Card className="animate-fade-in">
    <CardContent className="flex items-center gap-4 p-5">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div>
        <p className="text-2xl font-bold">{value}</p>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
    </CardContent>
  </Card>
);

const OverviewPage = () => {
  const { products, services, customers } = useCatalog();

  return (
    <div>
      <PageHeader title="DBS Product & Service Catalogue" description="Digital Banking Product & Service Catalog configuration" />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <StatCard icon={Package} label="Products" value={products.length} color="bg-primary text-primary-foreground" />
        <StatCard icon={Layers} label="Services" value={services.length} color="bg-accent text-accent-foreground" />
        <StatCard icon={Users} label="Customers" value={customers.length} color="bg-info text-info-foreground" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="animate-fade-in">
          <CardHeader>
            <CardTitle className="text-base">Products</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {products.map(p => (
              <div key={p.id} className="p-3 rounded-lg bg-muted/50">
                <p className="font-semibold text-sm mb-2">{p.name}</p>
                <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1">Payment Types</p>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {p.paymentTypes.map(f => <FeatureBadge key={f} feature={f} />)}
                </div>
                <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1">Features</p>
                <div className="flex flex-wrap gap-1.5">
                  {p.productFeatures.map(f => <FeatureBadge key={f} feature={f} />)}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="animate-fade-in">
          <CardHeader>
            <CardTitle className="text-base">Services</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {services.map(s => (
              <div key={s.id} className="p-3 rounded-lg bg-muted/50">
                <div className="flex items-start justify-between mb-2">
                  <p className="font-semibold text-sm">{s.name}</p>
                  <span className="font-mono text-xs bg-card border px-2 py-1 rounded">Code: {s.code}</span>
                </div>
                <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1">Payment Types</p>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {s.paymentTypes.map(f => <FeatureBadge key={f} feature={f} />)}
                </div>
                <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1">Features</p>
                <div className="flex flex-wrap gap-1.5">
                  {s.productFeatures.map(f => <FeatureBadge key={f} feature={f} />)}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="animate-fade-in lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Customer Subscriptions & Resolution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {customers.map(cust => {
                const product = products.find(p => p.id === cust.productId);
                const custServices = services.filter(s => cust.serviceIds.includes(s.id));
                const servicePaymentTypes = [...new Set(custServices.flatMap(s => s.paymentTypes))];
                const serviceFeatures = [...new Set(custServices.flatMap(s => s.productFeatures))];
                const productPayments = product?.paymentTypes || [];
                const productFeatures = product?.productFeatures || [];

                const resolvedPayments = productPayments.filter(pt => servicePaymentTypes.includes(pt));
                const blockedPayments = productPayments.filter(pt => !servicePaymentTypes.includes(pt));
                const resolvedFeatures = productFeatures.filter(f => serviceFeatures.includes(f));
                const blockedFeatures = productFeatures.filter(f => !serviceFeatures.includes(f));

                return (
                  <div key={cust.id} className="p-4 rounded-lg border bg-card">
                    <p className="font-semibold mb-1">{cust.name}</p>
                    <p className="text-xs text-muted-foreground mb-3">
                      {product?.name} — Services: {custServices.map(s => s.name).join(", ") || "None"}
                    </p>
                    <p className="text-xs font-medium text-success mb-1">✓ Available Payments</p>
                    <div className="flex flex-wrap gap-1 mb-2">
                      {resolvedPayments.map(f => <FeatureBadge key={f} feature={f} />)}
                      {resolvedPayments.length === 0 && <span className="text-xs text-muted-foreground">None</span>}
                    </div>
                    {blockedPayments.length > 0 && (
                      <>
                        <p className="text-xs font-medium text-destructive mb-1">✗ Payments Not in Services</p>
                        <div className="flex flex-wrap gap-1 mb-2">
                          {blockedPayments.map(f => (
                            <span key={f} className="text-xs bg-destructive/10 text-destructive px-2 py-0.5 rounded">{f}</span>
                          ))}
                        </div>
                      </>
                    )}
                    {productFeatures.length > 0 && (
                      <>
                        <p className="text-xs font-medium text-success mb-1">✓ Available Features</p>
                        <div className="flex flex-wrap gap-1 mb-2">
                          {resolvedFeatures.map(f => <FeatureBadge key={f} feature={f} />)}
                          {resolvedFeatures.length === 0 && <span className="text-xs text-muted-foreground">None</span>}
                        </div>
                        {blockedFeatures.length > 0 && (
                          <>
                            <p className="text-xs font-medium text-destructive mb-1">✗ Features Not in Services</p>
                            <div className="flex flex-wrap gap-1">
                              {blockedFeatures.map(f => (
                                <span key={f} className="text-xs bg-destructive/10 text-destructive px-2 py-0.5 rounded">{f}</span>
                              ))}
                            </div>
                          </>
                        )}
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default OverviewPage;
