import { useState } from "react";
import { useCatalog } from "@/context/CatalogContext";
import PageHeader from "@/components/PageHeader";
import FeatureBadge from "@/components/FeatureBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Customer } from "@/types/catalog";
import { Plus, Pencil, Trash2, CheckCircle2, XCircle } from "lucide-react";

const CustomersPage = () => {
  const { customers, products, services, addCustomer, updateCustomer, deleteCustomer } = useCatalog();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);
  const [name, setName] = useState("");
  const [productId, setProductId] = useState("");
  const [serviceIds, setServiceIds] = useState<string[]>([]);

  const openNew = () => { setEditing(null); setName(""); setProductId(products[0]?.id || ""); setServiceIds([]); setDialogOpen(true); };
  const openEdit = (c: Customer) => { setEditing(c); setName(c.name); setProductId(c.productId); setServiceIds([...c.serviceIds]); setDialogOpen(true); };

  const toggleService = (id: string) => {
    setServiceIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleSave = () => {
    if (!name.trim() || !productId) return;
    if (editing) {
      updateCustomer({ ...editing, name: name.trim(), productId, serviceIds });
    } else {
      addCustomer({ name: name.trim(), productId, serviceIds });
    }
    setDialogOpen(false);
  };

  return (
    <div>
      <PageHeader
        title="Customers"
        description="Manage customer subscriptions and view feature resolution"
        action={<Button onClick={openNew}><Plus className="w-4 h-4 mr-1.5" />Add Customer</Button>}
      />

      <div className="space-y-4">
        {customers.map(cust => {
          const product = products.find(p => p.id === cust.productId);
          const custServices = services.filter(s => cust.serviceIds.includes(s.id));
          const servicePaymentTypes = [...new Set(custServices.flatMap(s => s.paymentTypes))];
          const serviceFeatures = [...new Set(custServices.flatMap(s => s.productFeatures))];

          const productPayments = product?.paymentTypes || [];
          const productFeatures = product?.productFeatures || [];

          return (
            <Card key={cust.id} className="animate-fade-in group">
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-lg">{cust.name}</h3>
                    <p className="text-sm text-muted-foreground">{product?.name || "Unknown Product"}</p>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(cust)}>
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteCustomer(cust.id)}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>

                <div className="flex flex-col gap-4">
                  {/* Subscribed Services */}
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-2">Subscribed Services</p>
                    <div className="flex flex-wrap gap-2">
                      {custServices.map(s => (
                        <span key={s.id} className="px-3 py-1.5 rounded-md bg-accent/15 border border-accent/30 text-sm font-medium">
                          {s.name} <span className="font-mono text-xs text-muted-foreground">({s.code})</span>
                        </span>
                      ))}
                      {custServices.length === 0 && <span className="text-sm text-muted-foreground">No services</span>}
                    </div>
                  </div>

                  {/* Payment Types Resolution */}
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-2">Payment Types</p>
                    <div className="space-y-1.5">
                      {productPayments.map(pt => {
                        const available = servicePaymentTypes.includes(pt);
                        return (
                          <div key={pt} className="flex items-center gap-2 text-sm">
                            {available ? (
                              <CheckCircle2 className="w-4 h-4 text-success" />
                            ) : (
                              <XCircle className="w-4 h-4 text-destructive" />
                            )}
                            <span className={available ? "" : "text-muted-foreground line-through text-xs"}>{pt}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Product Features Resolution */}
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-2">Product Features</p>
                    <div className="space-y-1.5">
                      {productFeatures.map(f => {
                        const available = serviceFeatures.includes(f);
                        return (
                          <div key={f} className="flex items-center gap-2 text-sm">
                            {available ? (
                              <CheckCircle2 className="w-4 h-4 text-success" />
                            ) : (
                              <XCircle className="w-4 h-4 text-destructive" />
                            )}
                            <span className={available ? "" : "text-muted-foreground line-through text-xs"}>{f}</span>
                          </div>
                        );
                      })}
                      {productFeatures.length === 0 && <span className="text-sm text-muted-foreground">No features</span>}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Customer" : "New Customer"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Customer Name</Label>
              <Input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Customer 3" className="mt-1" />
            </div>
            <div>
              <Label>Account Product</Label>
              <Select value={productId} onValueChange={setProductId}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {products.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Services</Label>
              <div className="mt-2 space-y-2">
                {services.map(s => (
                  <div key={s.id} className="flex items-center gap-2">
                    <Checkbox id={`cust-svc-${s.id}`} checked={serviceIds.includes(s.id)} onCheckedChange={() => toggleService(s.id)} />
                    <label htmlFor={`cust-svc-${s.id}`} className="text-sm cursor-pointer">
                      {s.name} <span className="font-mono text-xs text-muted-foreground">({s.code})</span>
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? "Update" : "Create"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CustomersPage;
