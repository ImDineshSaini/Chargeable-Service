import { useState } from "react";
import { useCatalog } from "@/context/CatalogContext";
import PageHeader from "@/components/PageHeader";
import FeatureBadge from "@/components/FeatureBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Product, PaymentType, ProductFeature, ALL_PAYMENT_TYPES, ALL_PRODUCT_FEATURES } from "@/types/catalog";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const ProductsPage = () => {
  const { products, addProduct, updateProduct, deleteProduct } = useCatalog();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [name, setName] = useState("");
  const [paymentTypes, setPaymentTypes] = useState<PaymentType[]>([]);
  const [productFeatures, setProductFeatures] = useState<ProductFeature[]>([]);

  const openNew = () => { setEditing(null); setName(""); setPaymentTypes([]); setProductFeatures([]); setDialogOpen(true); };
  const openEdit = (p: Product) => { setEditing(p); setName(p.name); setPaymentTypes([...p.paymentTypes]); setProductFeatures([...p.productFeatures]); setDialogOpen(true); };

  const togglePayment = (f: PaymentType) => {
    setPaymentTypes(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);
  };
  const toggleFeature = (f: ProductFeature) => {
    setProductFeatures(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);
  };

  const handleSave = () => {
    if (!name.trim()) return;
    if (editing) {
      updateProduct({ ...editing, name: name.trim(), paymentTypes, productFeatures });
    } else {
      addProduct({ name: name.trim(), paymentTypes, productFeatures });
    }
    setDialogOpen(false);
  };

  return (
    <div>
      <PageHeader
        title="Products & Services"
        description="Define account types with their payment types and product features"
        action={<Button onClick={openNew}><Plus className="w-4 h-4 mr-1.5" />Add Product</Button>}
      />

      <div className="space-y-6">
        {products.map(p => (
          <Card key={p.id} className="animate-fade-in group">
            <CardContent className="p-0">
              {/* Product header */}
              <div className="flex items-center justify-between px-6 py-4 border-b">
                <h3 className="font-semibold text-lg">{p.name}</h3>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(p)}>
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => deleteProduct(p.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <Accordion type="multiple" defaultValue={["payments", "features"]} className="px-6">
                {/* Payment Types Section */}
                <AccordionItem value="payments">
                  <AccordionTrigger className="text-base font-semibold">Payment Types</AccordionTrigger>
                  <AccordionContent>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3 pb-2">
                      {ALL_PAYMENT_TYPES.map(pt => (
                        <div key={pt} className="flex items-center gap-3">
                          <Checkbox
                            id={`${p.id}-pt-${pt}`}
                            checked={p.paymentTypes.includes(pt)}
                            onCheckedChange={() => {
                              const next = p.paymentTypes.includes(pt)
                                ? p.paymentTypes.filter(x => x !== pt)
                                : [...p.paymentTypes, pt];
                              updateProduct({ ...p, paymentTypes: next });
                            }}
                          />
                          <label htmlFor={`${p.id}-pt-${pt}`} className="text-sm cursor-pointer select-none">{pt}</label>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Product Features Section */}
                <AccordionItem value="features">
                  <AccordionTrigger className="text-base font-semibold">
                    Product Features - {p.name}
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3 pb-2">
                      {ALL_PRODUCT_FEATURES.map(pf => (
                        <div key={pf} className="flex items-center gap-3">
                          <Checkbox
                            id={`${p.id}-pf-${pf}`}
                            checked={p.productFeatures.includes(pf)}
                            onCheckedChange={() => {
                              const next = p.productFeatures.includes(pf)
                                ? p.productFeatures.filter(x => x !== pf)
                                : [...p.productFeatures, pf];
                              updateProduct({ ...p, productFeatures: next });
                            }}
                          />
                          <label htmlFor={`${p.id}-pf-${pf}`} className="text-sm cursor-pointer select-none">{pf}</label>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Product" : "New Product"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-5 py-2">
            <div>
              <Label>Product Name</Label>
              <Input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Current Account" className="mt-1" />
            </div>
            <div>
              <Label className="text-base font-semibold">Payment Types</Label>
              <div className="mt-2 grid grid-cols-2 gap-x-6 gap-y-2">
                {ALL_PAYMENT_TYPES.map(f => (
                  <div key={f} className="flex items-center gap-2">
                    <Checkbox id={`new-pt-${f}`} checked={paymentTypes.includes(f)} onCheckedChange={() => togglePayment(f)} />
                    <label htmlFor={`new-pt-${f}`} className="text-sm cursor-pointer">{f}</label>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-base font-semibold">Product Features</Label>
              <div className="mt-2 grid grid-cols-2 gap-x-6 gap-y-2">
                {ALL_PRODUCT_FEATURES.map(f => (
                  <div key={f} className="flex items-center gap-2">
                    <Checkbox id={`new-pf-${f}`} checked={productFeatures.includes(f)} onCheckedChange={() => toggleFeature(f)} />
                    <label htmlFor={`new-pf-${f}`} className="text-sm cursor-pointer">{f}</label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? "Update" : "Create"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProductsPage;
