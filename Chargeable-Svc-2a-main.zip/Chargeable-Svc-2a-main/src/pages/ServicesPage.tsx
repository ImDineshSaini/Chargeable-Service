import { useState } from "react";
import { useCatalog } from "@/context/CatalogContext";
import PageHeader from "@/components/PageHeader";
import FeatureBadge from "@/components/FeatureBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Service, PaymentType, ProductFeature, ALL_PAYMENT_TYPES, ALL_PRODUCT_FEATURES } from "@/types/catalog";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const ServicesPage = () => {
  const { services, addService, updateService, deleteService } = useCatalog();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Service | null>(null);
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [paymentTypes, setPaymentTypes] = useState<PaymentType[]>([]);
  const [productFeatures, setProductFeatures] = useState<ProductFeature[]>([]);

  const openNew = () => { setEditing(null); setName(""); setCode(""); setPaymentTypes([]); setProductFeatures([]); setDialogOpen(true); };
  const openEdit = (s: Service) => { setEditing(s); setName(s.name); setCode(s.code); setPaymentTypes([...s.paymentTypes]); setProductFeatures([...s.productFeatures]); setDialogOpen(true); };

  const togglePayment = (f: PaymentType) => {
    setPaymentTypes(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);
  };
  const toggleFeature = (f: ProductFeature) => {
    setProductFeatures(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);
  };

  const handleSave = () => {
    if (!name.trim() || !code.trim()) return;
    if (editing) {
      updateService({ ...editing, name: name.trim(), code: code.trim(), paymentTypes, productFeatures });
    } else {
      addService({ name: name.trim(), code: code.trim(), paymentTypes, productFeatures });
    }
    setDialogOpen(false);
  };

  return (
    <div>
      <PageHeader
        title="Services"
        description="Define chargeable service bundles with payment type groupings"
        action={<Button onClick={openNew}><Plus className="w-4 h-4 mr-1.5" />Add Service</Button>}
      />

      <div className="space-y-6">
        {services.map(s => (
          <Card key={s.id} className="animate-fade-in group">
            <CardContent className="p-0">
              {/* Service header */}
              <div className="flex items-center justify-between px-6 py-4 border-b">
                <div className="flex items-center gap-3">
                  <span className="w-9 h-9 rounded-lg bg-accent text-accent-foreground flex items-center justify-center text-sm font-bold">{s.name}</span>
                  <div>
                    <h3 className="font-semibold text-lg">{s.name}</h3>
                  </div>
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(s)}>
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => deleteService(s.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <Accordion type="multiple" defaultValue={["partner-code", "payments", "features"]} className="px-6">
                {/* Partner Code Section */}
                <AccordionItem value="partner-code">
                  <AccordionTrigger className="text-base font-semibold">Partner Code Mapping</AccordionTrigger>
                  <AccordionContent>
                    <div className="max-w-sm pb-2">
                      <Label htmlFor={`code-${s.id}`} className="text-sm text-muted-foreground mb-1.5 block">Service Code</Label>
                      <Input
                        id={`code-${s.id}`}
                        value={s.code}
                        onChange={e => updateService({ ...s, code: e.target.value })}
                        placeholder="e.g. A0"
                        className="font-mono"
                      />
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Payment Types Section */}
                <AccordionItem value="payments">
                  <AccordionTrigger className="text-base font-semibold">Payment Types</AccordionTrigger>
                  <AccordionContent>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3 pb-2">
                      {ALL_PAYMENT_TYPES.map(pt => (
                        <div key={pt} className="flex items-center gap-3">
                          <Checkbox
                            id={`${s.id}-pt-${pt}`}
                            checked={s.paymentTypes.includes(pt)}
                            onCheckedChange={() => {
                              const next = s.paymentTypes.includes(pt)
                                ? s.paymentTypes.filter(x => x !== pt)
                                : [...s.paymentTypes, pt];
                              updateService({ ...s, paymentTypes: next });
                            }}
                          />
                          <label htmlFor={`${s.id}-pt-${pt}`} className="text-sm cursor-pointer select-none">{pt}</label>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Product Features Section */}
                <AccordionItem value="features">
                  <AccordionTrigger className="text-base font-semibold">Product Features</AccordionTrigger>
                  <AccordionContent>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3 pb-2">
                      {ALL_PRODUCT_FEATURES.map(pf => (
                        <div key={pf} className="flex items-center gap-3">
                          <Checkbox
                            id={`${s.id}-pf-${pf}`}
                            checked={s.productFeatures.includes(pf)}
                            onCheckedChange={() => {
                              const next = s.productFeatures.includes(pf)
                                ? s.productFeatures.filter(x => x !== pf)
                                : [...s.productFeatures, pf];
                              updateService({ ...s, productFeatures: next });
                            }}
                          />
                          <label htmlFor={`${s.id}-pf-${pf}`} className="text-sm cursor-pointer select-none">{pf}</label>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Service" : "New Service"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-5 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Service Name</Label>
                <Input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. S4" className="mt-1" />
              </div>
              <div>
                <Label>Partner Code</Label>
                <Input value={code} onChange={e => setCode(e.target.value)} placeholder="e.g. A0" className="mt-1 font-mono" />
              </div>
            </div>
            <div>
              <Label className="text-base font-semibold">Payment Types</Label>
              <div className="mt-2 grid grid-cols-2 gap-x-6 gap-y-2">
                {ALL_PAYMENT_TYPES.map(f => (
                  <div key={f} className="flex items-center gap-2">
                    <Checkbox id={`new-svc-${f}`} checked={paymentTypes.includes(f)} onCheckedChange={() => togglePayment(f)} />
                    <label htmlFor={`new-svc-${f}`} className="text-sm cursor-pointer">{f}</label>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-base font-semibold">Product Features</Label>
              <div className="mt-2 grid grid-cols-2 gap-x-6 gap-y-2">
                {ALL_PRODUCT_FEATURES.map(f => (
                  <div key={f} className="flex items-center gap-2">
                    <Checkbox id={`new-svc-pf-${f}`} checked={productFeatures.includes(f)} onCheckedChange={() => toggleFeature(f)} />
                    <label htmlFor={`new-svc-pf-${f}`} className="text-sm cursor-pointer">{f}</label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? "Update" : "Create"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ServicesPage;
