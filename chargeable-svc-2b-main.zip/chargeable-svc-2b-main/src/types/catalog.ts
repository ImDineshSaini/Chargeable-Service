// Types for the Product Catalog Configuration Module

// Payment Types — transfer/payment methods configurable per product
export type PaymentType =
  | "SEPA EUR TRANSFER"
  | "P2P Transfer ETB"
  | "Local Transfer France"
  | "Local Transfer Ethiopia"
  | "Local Transfer Algeria"
  | "Internal Transfer EUR"
  | "Internal Transfer ETB"
  | "Internal Transfer DZD"
  | "One Off"
  | "SEPA Transfer France"
  | "Internal Transfer ARS V 5"
  | "P2P Transfer EUR"
  | "P2P Transfer DZD New 1";

export const ALL_PAYMENT_TYPES: PaymentType[] = [
  "SEPA EUR TRANSFER",
  "P2P Transfer ETB",
  "Local Transfer France",
  "Local Transfer Ethiopia",
  "Local Transfer Algeria",
  "Internal Transfer EUR",
  "Internal Transfer ETB",
  "Internal Transfer DZD",
  "One Off",
  "SEPA Transfer France",
  "Internal Transfer ARS V 5",
  "P2P Transfer EUR",
  "P2P Transfer DZD New 1",
];

// Product Features — account-level capabilities
export type ProductFeature =
  | "View Statement"
  | "Change Account Name"
  | "Savings goal"
  | "Order chequebook"
  | "Download Proof Of Account";

export const ALL_PRODUCT_FEATURES: ProductFeature[] = [
  "View Statement",
  "Change Account Name",
  "Savings goal",
  "Order chequebook",
  "Download Proof Of Account",
];

export interface Product {
  id: string;
  name: string;
  /** All payment types available as chargeable options on this product */
  paymentTypes: PaymentType[];
  /** All product features available as chargeable options on this product */
  productFeatures: ProductFeature[];
}

export interface Service {
  id: string;
  name: string;
  code: string;
  /** The product this service belongs to as an add-on */
  productId: string;
  /** Payment types this service unlocks when subscribed */
  paymentTypes: PaymentType[];
  /** Product features this service unlocks when subscribed */
  productFeatures: ProductFeature[];
}

export interface Customer {
  id: string;
  name: string;
  productId: string;
  serviceIds: string[];
}

// Initial seed data
export const INITIAL_PRODUCTS: Product[] = [
  {
    id: "prod-1",
    name: "Current Account",
    paymentTypes: ["Local Transfer France", "Internal Transfer EUR", "SEPA Transfer France"],
    productFeatures: ["View Statement", "Change Account Name", "Order chequebook", "Download Proof Of Account"],
  },
  {
    id: "prod-2",
    name: "Premium Account",
    paymentTypes: ["SEPA EUR TRANSFER", "Local Transfer France", "Internal Transfer EUR", "SEPA Transfer France", "P2P Transfer EUR"],
    productFeatures: ["View Statement", "Change Account Name", "Savings goal", "Order chequebook", "Download Proof Of Account"],
  },
];

export const INITIAL_SERVICES: Service[] = [
  {
    id: "svc-1",
    name: "S1",
    code: "A0",
    productId: "prod-1",
    paymentTypes: ["Internal Transfer EUR", "SEPA Transfer France"],
    productFeatures: ["View Statement", "Change Account Name"],
  },
  {
    id: "svc-2",
    name: "S2",
    code: "A1",
    productId: "prod-2",
    paymentTypes: ["P2P Transfer EUR", "SEPA EUR TRANSFER"],
    productFeatures: ["Savings goal", "Download Proof Of Account"],
  },
  {
    id: "svc-3",
    name: "S3",
    code: "B2",
    productId: "prod-1",
    paymentTypes: ["Local Transfer France"],
    productFeatures: ["Order chequebook", "View Statement"],
  },
];

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: "cust-1",
    name: "Customer 1",
    productId: "prod-1",
    serviceIds: ["svc-1"],
  },
  {
    id: "cust-2",
    name: "Customer 2",
    productId: "prod-2",
    serviceIds: ["svc-2"],
  },
];
