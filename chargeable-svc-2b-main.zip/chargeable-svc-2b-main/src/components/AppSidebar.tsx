import { NavLink } from "react-router-dom";
import { Package, Layers, Users, BarChart3 } from "lucide-react";

const navItems = [
  { to: "/", icon: BarChart3, label: "Overview" },
  { to: "/products", icon: Package, label: "Products" },
  { to: "/services", icon: Layers, label: "Services" },
  { to: "/customers", icon: Users, label: "Customers" },
];

const AppSidebar = () => {
  return (
    <aside className="w-60 min-h-screen bg-sidebar text-sidebar-foreground flex flex-col border-r border-sidebar-border">
      <div className="p-5 border-b border-sidebar-border">
        <h1 className="text-lg font-bold tracking-tight text-sidebar-primary-foreground">DBS Platform</h1>
        <p className="text-xs text-sidebar-foreground/60 mt-0.5">Product & Service Catalog</p>
      </div>
      <nav className="flex-1 p-3 space-y-1">
        {navItems.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === "/"}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-primary"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
              }`
            }
          >
            <item.icon className="w-4 h-4" />
            {item.label}
          </NavLink>
        ))}
      </nav>
      <div className="p-4 border-t border-sidebar-border text-xs text-sidebar-foreground/40">
        v1.0 — Back Office
      </div>
    </aside>
  );
};

export default AppSidebar;
