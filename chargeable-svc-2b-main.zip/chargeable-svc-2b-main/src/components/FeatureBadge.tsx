import { Badge } from "@/components/ui/badge";
import { PaymentType, ProductFeature } from "@/types/catalog";

const paymentColorMap: Record<string, string> = {
  "SEPA EUR TRANSFER": "bg-success text-success-foreground",
  "P2P Transfer ETB": "bg-accent text-accent-foreground",
  "Local Transfer France": "bg-primary text-primary-foreground",
  "Local Transfer Ethiopia": "bg-accent text-accent-foreground",
  "Local Transfer Algeria": "bg-info text-info-foreground",
  "Internal Transfer EUR": "bg-primary text-primary-foreground",
  "Internal Transfer ETB": "bg-accent text-accent-foreground",
  "Internal Transfer DZD": "bg-info text-info-foreground",
  "One Off": "bg-warning text-warning-foreground",
  "SEPA Transfer France": "bg-success text-success-foreground",
  "Internal Transfer ARS V 5": "bg-info text-info-foreground",
  "P2P Transfer EUR": "bg-primary text-primary-foreground",
  "P2P Transfer DZD New 1": "bg-accent text-accent-foreground",
};

const featureColorMap: Record<string, string> = {
  "View Statement": "bg-info text-info-foreground",
  "Change Account Name": "bg-primary text-primary-foreground",
  "Savings goal": "bg-success text-success-foreground",
  "Order chequebook": "bg-accent text-accent-foreground",
  "Download Proof Of Account": "bg-warning text-warning-foreground",
};

const FeatureBadge: React.FC<{ feature: PaymentType | ProductFeature; showCategory?: boolean }> = ({ feature }) => {
  const color = paymentColorMap[feature] || featureColorMap[feature] || "bg-muted text-muted-foreground";
  return (
    <Badge className={`${color} text-xs font-medium`}>
      {feature}
    </Badge>
  );
};

export default FeatureBadge;
