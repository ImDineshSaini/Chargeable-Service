import React, { createContext, useContext, useState, useCallback } from "react";
import {
  Product, Service, Customer,
  INITIAL_PRODUCTS, INITIAL_SERVICES, INITIAL_CUSTOMERS,
} from "@/types/catalog";

interface CatalogContextType {
  products: Product[];
  services: Service[];
  customers: Customer[];
  addProduct: (p: Omit<Product, "id">) => void;
  updateProduct: (p: Product) => void;
  deleteProduct: (id: string) => void;
  addService: (s: Omit<Service, "id">) => void;
  updateService: (s: Service) => void;
  deleteService: (id: string) => void;
  addCustomer: (c: Omit<Customer, "id">) => void;
  updateCustomer: (c: Customer) => void;
  deleteCustomer: (id: string) => void;
}

const CatalogContext = createContext<CatalogContextType | null>(null);

let idCounter = 100;
const genId = (prefix: string) => `${prefix}-${++idCounter}`;

export const CatalogProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [services, setServices] = useState<Service[]>(INITIAL_SERVICES);
  const [customers, setCustomers] = useState<Customer[]>(INITIAL_CUSTOMERS);

  const addProduct = useCallback((p: Omit<Product, "id">) => {
    setProducts(prev => [...prev, { ...p, id: genId("prod") }]);
  }, []);
  const updateProduct = useCallback((p: Product) => {
    setProducts(prev => prev.map(x => x.id === p.id ? p : x));
  }, []);
  const deleteProduct = useCallback((id: string) => {
    setProducts(prev => prev.filter(x => x.id !== id));
  }, []);

  const addService = useCallback((s: Omit<Service, "id">) => {
    setServices(prev => [...prev, { ...s, id: genId("svc") }]);
  }, []);
  const updateService = useCallback((s: Service) => {
    setServices(prev => prev.map(x => x.id === s.id ? s : x));
  }, []);
  const deleteService = useCallback((id: string) => {
    setServices(prev => prev.filter(x => x.id !== id));
  }, []);


  const addCustomer = useCallback((c: Omit<Customer, "id">) => {
    setCustomers(prev => [...prev, { ...c, id: genId("cust") }]);
  }, []);
  const updateCustomer = useCallback((c: Customer) => {
    setCustomers(prev => prev.map(x => x.id === c.id ? c : x));
  }, []);
  const deleteCustomer = useCallback((id: string) => {
    setCustomers(prev => prev.filter(x => x.id !== id));
  }, []);

  return (
    <CatalogContext.Provider value={{
      products, services, customers,
      addProduct, updateProduct, deleteProduct,
      addService, updateService, deleteService,
      addCustomer, updateCustomer, deleteCustomer,
    }}>
      {children}
    </CatalogContext.Provider>
  );
};

export const useCatalog = () => {
  const ctx = useContext(CatalogContext);
  if (!ctx) throw new Error("useCatalog must be used within CatalogProvider");
  return ctx;
};
