import { useState } from "react";
import { useCatalog } from "@/context/CatalogContext";
import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Service, PaymentType, ProductFeature } from "@/types/catalog";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";

const ServicesPage = () => {
  const { products, services, addService, updateService, deleteService } = useCatalog();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Service | null>(null);
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [productId, setProductId] = useState("");
  const [paymentTypes, setPaymentTypes] = useState<PaymentType[]>([]);
  const [productFeatures, setProductFeatures] = useState<ProductFeature[]>([]);

  const openNew = () => {
    setEditing(null); setName(""); setCode(""); setProductId(products[0]?.id || "");
    setPaymentTypes([]); setProductFeatures([]); setDialogOpen(true);
  };
  const openEdit = (s: Service) => {
    setEditing(s); setName(s.name); setCode(s.code); setProductId(s.productId);
    setPaymentTypes([...s.paymentTypes]); setProductFeatures([...s.productFeatures]); setDialogOpen(true);
  };

  const togglePayment = (f: PaymentType) => {
    setPaymentTypes(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);
  };
  const toggleFeature = (f: ProductFeature) => {
    setProductFeatures(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);
  };

  const handleSave = () => {
    if (!name.trim() || !code.trim() || !productId) return;
    if (editing) {
      updateService({ ...editing, name: name.trim(), code: code.trim(), productId, paymentTypes, productFeatures });
    } else {
      addService({ name: name.trim(), code: code.trim(), productId, paymentTypes, productFeatures });
    }
    setDialogOpen(false);
  };

  // Get available options from selected product (for dialog)
  const selectedProduct = products.find(p => p.id === productId);
  const availablePayments = selectedProduct?.paymentTypes || [];
  const availableFeatures = selectedProduct?.productFeatures || [];

  return (
    <div>
      <PageHeader
        title="Services (Add-ons)"
        description="Define subscribable service add-ons that unlock payment types and features from a product"
        action={<Button onClick={openNew}><Plus className="w-4 h-4 mr-1.5" />Add Service</Button>}
      />

      <div className="space-y-6">
        {services.map(s => {
          const parentProduct = products.find(p => p.id === s.productId);
          return (
            <Card key={s.id} className="animate-fade-in group">
              <CardContent className="p-0">
                <div className="flex items-center justify-between px-6 py-4 border-b">
                  <div className="flex items-center gap-3">
                    <span className="w-9 h-9 rounded-lg bg-accent text-accent-foreground flex items-center justify-center text-sm font-bold">{s.name}</span>
                    <div>
                      <h3 className="font-semibold text-lg">{s.name}</h3>
                      <p className="text-xs text-muted-foreground">
                        Add-on for <span className="font-medium text-foreground">{parentProduct?.name || "Unknown"}</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(s)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => deleteService(s.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <Accordion type="multiple" defaultValue={["partner-code", "payments", "features"]} className="px-6">
                  <AccordionItem value="partner-code">
                    <AccordionTrigger className="text-base font-semibold">Partner Code Mapping</AccordionTrigger>
                    <AccordionContent>
                      <div className="max-w-sm pb-2">
                        <Label htmlFor={`code-${s.id}`} className="text-sm text-muted-foreground mb-1.5 block">Service Code</Label>
                        <Input
                          id={`code-${s.id}`}
                          value={s.code}
                          onChange={e => updateService({ ...s, code: e.target.value })}
                          placeholder="e.g. A0"
                          className="font-mono"
                        />
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="payments">
                    <AccordionTrigger className="text-base font-semibold">Unlocked Payment Types</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-xs text-muted-foreground mb-3">
                        Select which of <span className="font-medium">{parentProduct?.name}</span>'s payment types this service unlocks when subscribed.
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3 pb-2">
                        {(parentProduct?.paymentTypes || []).map(pt => (
                          <div key={pt} className="flex items-center gap-3">
                            <Checkbox
                              id={`${s.id}-pt-${pt}`}
                              checked={s.paymentTypes.includes(pt)}
                              onCheckedChange={() => {
                                const next = s.paymentTypes.includes(pt)
                                  ? s.paymentTypes.filter(x => x !== pt)
                                  : [...s.paymentTypes, pt];
                                updateService({ ...s, paymentTypes: next });
                              }}
                            />
                            <label htmlFor={`${s.id}-pt-${pt}`} className="text-sm cursor-pointer select-none">{pt}</label>
                          </div>
                        ))}
                        {(!parentProduct || parentProduct.paymentTypes.length === 0) && (
                          <p className="text-sm text-muted-foreground">No payment types available on parent product.</p>
                        )}
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="features">
                    <AccordionTrigger className="text-base font-semibold">Unlocked Product Features</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-xs text-muted-foreground mb-3">
                        Select which of <span className="font-medium">{parentProduct?.name}</span>'s features this service unlocks when subscribed.
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3 pb-2">
                        {(parentProduct?.productFeatures || []).map(pf => (
                          <div key={pf} className="flex items-center gap-3">
                            <Checkbox
                              id={`${s.id}-pf-${pf}`}
                              checked={s.productFeatures.includes(pf)}
                              onCheckedChange={() => {
                                const next = s.productFeatures.includes(pf)
                                  ? s.productFeatures.filter(x => x !== pf)
                                  : [...s.productFeatures, pf];
                                updateService({ ...s, productFeatures: next });
                              }}
                            />
                            <label htmlFor={`${s.id}-pf-${pf}`} className="text-sm cursor-pointer select-none">{pf}</label>
                          </div>
                        ))}
                        {(!parentProduct || parentProduct.productFeatures.length === 0) && (
                          <p className="text-sm text-muted-foreground">No features available on parent product.</p>
                        )}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Service" : "New Service"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-5 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Service Name</Label>
                <Input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. S4" className="mt-1" />
              </div>
              <div>
                <Label>Partner Code</Label>
                <Input value={code} onChange={e => setCode(e.target.value)} placeholder="e.g. A0" className="mt-1 font-mono" />
              </div>
            </div>
            <div>
              <Label>Parent Product</Label>
              <p className="text-xs text-muted-foreground mb-1">This service will be an add-on for the selected product.</p>
              <Select value={productId} onValueChange={(v) => { setProductId(v); setPaymentTypes([]); setProductFeatures([]); }}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select a product" /></SelectTrigger>
                <SelectContent>
                  {products.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {selectedProduct && (
              <>
                <div>
                  <Label className="text-base font-semibold">Unlocked Payment Types</Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Choose which of {selectedProduct.name}'s payment types this service unlocks.
                  </p>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-2">
                    {availablePayments.map(f => (
                      <div key={f} className="flex items-center gap-2">
                        <Checkbox id={`new-svc-${f}`} checked={paymentTypes.includes(f)} onCheckedChange={() => togglePayment(f)} />
                        <label htmlFor={`new-svc-${f}`} className="text-sm cursor-pointer">{f}</label>
                      </div>
                    ))}
                    {availablePayments.length === 0 && <p className="text-sm text-muted-foreground">No payment types on this product.</p>}
                  </div>
                </div>
                <div>
                  <Label className="text-base font-semibold">Unlocked Product Features</Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Choose which of {selectedProduct.name}'s features this service unlocks.
                  </p>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-2">
                    {availableFeatures.map(f => (
                      <div key={f} className="flex items-center gap-2">
                        <Checkbox id={`new-svc-pf-${f}`} checked={productFeatures.includes(f)} onCheckedChange={() => toggleFeature(f)} />
                        <label htmlFor={`new-svc-pf-${f}`} className="text-sm cursor-pointer">{f}</label>
                      </div>
                    ))}
                    {availableFeatures.length === 0 && <p className="text-sm text-muted-foreground">No features on this product.</p>}
                  </div>
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? "Update" : "Create"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ServicesPage;
