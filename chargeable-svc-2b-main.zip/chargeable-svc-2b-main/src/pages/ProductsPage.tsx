import { useState } from "react";
import { useCatalog } from "@/context/CatalogContext";
import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Product, PaymentType, ProductFeature, ALL_PAYMENT_TYPES, ALL_PRODUCT_FEATURES } from "@/types/catalog";
import { Plus, Pencil, Trash2, CreditCard, Sparkles } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";

const ProductsPage = () => {
  const { products, services, addProduct, updateProduct, deleteProduct } = useCatalog();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [name, setName] = useState("");
  const [paymentTypes, setPaymentTypes] = useState<PaymentType[]>([]);
  const [productFeatures, setProductFeatures] = useState<ProductFeature[]>([]);

  const openNew = () => { setEditing(null); setName(""); setPaymentTypes([]); setProductFeatures([]); setDialogOpen(true); };
  const openEdit = (p: Product) => { setEditing(p); setName(p.name); setPaymentTypes([...p.paymentTypes]); setProductFeatures([...p.productFeatures]); setDialogOpen(true); };

  const togglePayment = (f: PaymentType) => {
    setPaymentTypes(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);
  };
  const toggleFeature = (f: ProductFeature) => {
    setProductFeatures(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);
  };

  const handleSave = () => {
    if (!name.trim()) return;
    if (editing) {
      updateProduct({ ...editing, name: name.trim(), paymentTypes, productFeatures });
    } else {
      addProduct({ name: name.trim(), paymentTypes, productFeatures });
    }
    setDialogOpen(false);
  };

  const getProductServices = (productId: string) => services.filter(s => s.productId === productId);

  return (
    <div>
      <PageHeader
        title="Products"
        description="Define account types with their chargeable payment types and features. Services act as subscribable add-ons."
        action={<Button onClick={openNew}><Plus className="w-4 h-4 mr-1.5" />Add Product</Button>}
      />

      <div className="space-y-6">
        {products.map(p => {
          const linkedServices = getProductServices(p.id);
          return (
            <Card key={p.id} className="animate-fade-in group">
              <CardContent className="p-0">
                <div className="flex items-center justify-between px-6 py-4 border-b">
                  <div>
                    <h3 className="font-semibold text-lg">{p.name}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {linkedServices.length} add-on service{linkedServices.length !== 1 ? "s" : ""} available
                    </p>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(p)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => deleteProduct(p.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <Accordion type="multiple" defaultValue={["payments", "features", "services"]} className="px-6">
                  <AccordionItem value="payments">
                    <AccordionTrigger className="text-base font-semibold">
                      <span className="flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-muted-foreground" />
                        Chargeable Payment Types
                      </span>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3 pb-2">
                        {ALL_PAYMENT_TYPES.map(pt => (
                          <div key={pt} className="flex items-center gap-3">
                            <Checkbox
                              id={`${p.id}-pt-${pt}`}
                              checked={p.paymentTypes.includes(pt)}
                              onCheckedChange={() => {
                                const next = p.paymentTypes.includes(pt)
                                  ? p.paymentTypes.filter(x => x !== pt)
                                  : [...p.paymentTypes, pt];
                                updateProduct({ ...p, paymentTypes: next });
                              }}
                            />
                            <label htmlFor={`${p.id}-pt-${pt}`} className="text-sm cursor-pointer select-none">{pt}</label>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="features">
                    <AccordionTrigger className="text-base font-semibold">
                      <span className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-muted-foreground" />
                        Chargeable Product Features
                      </span>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3 pb-2">
                        {ALL_PRODUCT_FEATURES.map(pf => (
                          <div key={pf} className="flex items-center gap-3">
                            <Checkbox
                              id={`${p.id}-pf-${pf}`}
                              checked={p.productFeatures.includes(pf)}
                              onCheckedChange={() => {
                                const next = p.productFeatures.includes(pf)
                                  ? p.productFeatures.filter(x => x !== pf)
                                  : [...p.productFeatures, pf];
                                updateProduct({ ...p, productFeatures: next });
                              }}
                            />
                            <label htmlFor={`${p.id}-pf-${pf}`} className="text-sm cursor-pointer select-none">{pf}</label>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="services">
                    <AccordionTrigger className="text-base font-semibold">
                      Linked Add-on Services
                    </AccordionTrigger>
                    <AccordionContent>
                      {linkedServices.length === 0 ? (
                        <p className="text-sm text-muted-foreground pb-2">No services linked to this product yet.</p>
                      ) : (
                        <div className="space-y-2 pb-2">
                          {linkedServices.map(s => (
                            <div key={s.id} className="flex items-center gap-3 p-2 rounded-md bg-muted/50">
                              <Badge variant="secondary" className="font-mono">{s.code}</Badge>
                              <span className="text-sm font-medium">{s.name}</span>
                              <span className="text-xs text-muted-foreground ml-auto">
                                {s.paymentTypes.length} payments · {s.productFeatures.length} features
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Product" : "New Product"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-5 py-2">
            <div>
              <Label>Product Name</Label>
              <Input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Current Account" className="mt-1" />
            </div>
            <div>
              <Label className="text-base font-semibold">Chargeable Payment Types</Label>
              <p className="text-xs text-muted-foreground mb-2">Select which payment types can be offered as chargeable options through service add-ons.</p>
              <div className="grid grid-cols-2 gap-x-6 gap-y-2">
                {ALL_PAYMENT_TYPES.map(f => (
                  <div key={f} className="flex items-center gap-2">
                    <Checkbox id={`new-pt-${f}`} checked={paymentTypes.includes(f)} onCheckedChange={() => togglePayment(f)} />
                    <label htmlFor={`new-pt-${f}`} className="text-sm cursor-pointer">{f}</label>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-base font-semibold">Chargeable Product Features</Label>
              <p className="text-xs text-muted-foreground mb-2">Select which features can be offered as chargeable options through service add-ons.</p>
              <div className="grid grid-cols-2 gap-x-6 gap-y-2">
                {ALL_PRODUCT_FEATURES.map(f => (
                  <div key={f} className="flex items-center gap-2">
                    <Checkbox id={`new-pf-${f}`} checked={productFeatures.includes(f)} onCheckedChange={() => toggleFeature(f)} />
                    <label htmlFor={`new-pf-${f}`} className="text-sm cursor-pointer">{f}</label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? "Update" : "Create"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProductsPage;
